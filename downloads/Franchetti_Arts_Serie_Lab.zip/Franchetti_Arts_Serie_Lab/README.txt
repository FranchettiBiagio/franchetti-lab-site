FRANCHETTI ARTS - SERIE LAB
24 LUT 3D per Franchetti Lab e Franchetti Raw Converter Pro

Cosa sono
  Look originali in formato Adobe Cube (.cube), dimensione 17.
  Non ripetono i 108 look della prima serie Franchetti Arts.

Come si usano in Franchetti Lab
  1. Apri la scheda "Applica LUT".
  2. Scegli un file .cube da questa cartella.
  3. Regola l'intensita' e avvia l'elaborazione.

Come si usano in Franchetti Raw Converter Pro
  1. REGOLAZIONI AVANZATE.
  2. Card "CURVA TONALE E SPLIT TONING".
  3. "LUT 3D (.cube):" -> Scegli.
  4. Regola "Intensita' LUT".

Elenco
01. Ambra Toscana
02. Miele di Castagno
03. Terracotta
04. Ocra
05. Arancio Bruciato
06. Sabbia Chiara
07. Cobalto Profondo
08. Blu Ghiaccio
09. Lavanda
10. Petrolio
11. Nebbia Alta
12. Notte Blu
13. Salvia Grigia
14. Eucalipto
15. Verde Muschio
16. Cedro
17. Ruggine Viva
18. Corallo Antico
19. Bordeaux
20. Seta Calda
21. Cipria
22. Indaco Elettrico
23. Magenta Laser
24. Grafite

Licenza: vedi LICENZA.txt - uso libero anche commerciale, senza royalty.
