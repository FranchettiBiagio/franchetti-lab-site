# Franchetti Arts - Serie Lab

01. Ambra Toscana  ->  FranchettiArts_Lab_01_Ambra_Toscana.cube
02. Miele di Castagno  ->  FranchettiArts_Lab_02_Miele_di_Castagno.cube
03. Terracotta  ->  FranchettiArts_Lab_03_Terracotta.cube
04. Ocra  ->  FranchettiArts_Lab_04_Ocra.cube
05. Arancio Bruciato  ->  FranchettiArts_Lab_05_Arancio_Bruciato.cube
06. Sabbia Chiara  ->  FranchettiArts_Lab_06_Sabbia_Chiara.cube
07. Cobalto Profondo  ->  FranchettiArts_Lab_07_Cobalto_Profondo.cube
08. Blu Ghiaccio  ->  FranchettiArts_Lab_08_Blu_Ghiaccio.cube
09. Lavanda  ->  FranchettiArts_Lab_09_Lavanda.cube
10. Petrolio  ->  FranchettiArts_Lab_10_Petrolio.cube
11. Nebbia Alta  ->  FranchettiArts_Lab_11_Nebbia_Alta.cube
12. Notte Blu  ->  FranchettiArts_Lab_12_Notte_Blu.cube
13. Salvia Grigia  ->  FranchettiArts_Lab_13_Salvia_Grigia.cube
14. Eucalipto  ->  FranchettiArts_Lab_14_Eucalipto.cube
15. Verde Muschio  ->  FranchettiArts_Lab_15_Verde_Muschio.cube
16. Cedro  ->  FranchettiArts_Lab_16_Cedro.cube
17. Ruggine Viva  ->  FranchettiArts_Lab_17_Ruggine_Viva.cube
18. Corallo Antico  ->  FranchettiArts_Lab_18_Corallo_Antico.cube
19. Bordeaux  ->  FranchettiArts_Lab_19_Bordeaux.cube
20. Seta Calda  ->  FranchettiArts_Lab_20_Seta_Calda.cube
21. Cipria  ->  FranchettiArts_Lab_21_Cipria.cube
22. Indaco Elettrico  ->  FranchettiArts_Lab_22_Indaco_Elettrico.cube
23. Magenta Laser  ->  FranchettiArts_Lab_23_Magenta_Laser.cube
24. Grafite  ->  FranchettiArts_Lab_24_Grafite.cube
